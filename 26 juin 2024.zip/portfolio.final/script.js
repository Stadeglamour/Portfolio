// Gestion du carrousel
const carouselTrack = document.querySelector('.carousel-track');
const carouselItems = document.querySelectorAll('.carousel-item');
const prevButton = document.querySelector('.carousel-prev');
const nextButton = document.querySelector('.carousel-next');

const slideWidth = carouselItems[0].clientWidth;
let currentIndex = 0;

nextButton.addEventListener('click', () => {
    currentIndex++;
    updateCarouselPosition();
});

prevButton.addEventListener('click', () => {
    currentIndex--;
    updateCarouselPosition();
});

function updateCarouselPosition() {
    const offset = -currentIndex * slideWidth;
    carouselTrack.style.transform = `translateX(${offset}px)`;

    // Gestion de l'état des boutons
    prevButton.disabled = currentIndex === 0;
    nextButton.disabled = currentIndex === carouselItems.length - 1;
}

// Gestion de la barre de défilement
const scrollbarTrack = document.querySelector('.scrollbar-track');
const scrollbarThumb = document.querySelector('.scrollbar-thumb');

scrollbarTrack.addEventListener('scroll', () => {
    const scrollPercentage = (scrollbarTrack.scrollLeft / (scrollbarTrack.scrollWidth - scrollbarTrack.clientWidth)) * 100;
    const thumbWidth = (scrollbarThumb.clientWidth / scrollbarTrack.clientWidth) * 100;
    const thumbPosition = scrollPercentage * (scrollbarTrack.clientWidth / 100) - (thumbWidth / 2);

    scrollbarThumb.style.left = `${thumbPosition}%`;
});

scrollbarThumb.addEventListener('mousedown', (e) => {
    e.preventDefault();

    const initialX = e.clientX;
    const initialLeft = scrollbarThumb.offsetLeft;

    const onMouseMove = (event) => {
        const dx = event.clientX - initialX;
        const newLeft = Math.min(Math.max(initialLeft + dx, 0), scrollbarTrack.clientWidth - scrollbarThumb.clientWidth);

        const thumbPercentage = (newLeft / scrollbarTrack.clientWidth) * 100;
        const scrollPercentage = (thumbPercentage * (scrollbarTrack.scrollWidth - scrollbarTrack.clientWidth)) / 100;

        scrollbarTrack.scrollLeft = scrollPercentage;
        scrollbarThumb.style.left = `${thumbPercentage}%`;
    };

    const onMouseUp = () => {
        document.removeEventListener('mousemove', onMouseMove);
        document.removeEventListener('mouseup', onMouseUp);
    };

    document.addEventListener('mousemove', onMouseMove);
    document.addEventListener('mouseup', onMouseUp);
});
